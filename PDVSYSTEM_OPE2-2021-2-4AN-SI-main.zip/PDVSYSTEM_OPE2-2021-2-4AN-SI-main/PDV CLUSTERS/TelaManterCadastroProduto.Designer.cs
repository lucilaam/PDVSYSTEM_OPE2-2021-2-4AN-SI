﻿
namespace PDV_CLUSTERS
{
    partial class TelaManterCadastroProduto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1_CodBarras = new System.Windows.Forms.Label();
            this.label2_Idinterno = new System.Windows.Forms.Label();
            this.label3_nomeProduto = new System.Windows.Forms.Label();
            this.label4_qtde = new System.Windows.Forms.Label();
            this.label6_margemLucro = new System.Windows.Forms.Label();
            this.label10_precoVenda = new System.Windows.Forms.Label();
            this.label11_precoCompra = new System.Windows.Forms.Label();
            this.textcodbarras = new System.Windows.Forms.TextBox();
            this.textcodinterno = new System.Windows.Forms.TextBox();
            this.textnome = new System.Windows.Forms.TextBox();
            this.textquantidade = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textprecocompra = new System.Windows.Forms.TextBox();
            this.textprecovenda = new System.Windows.Forms.TextBox();
            this.textmargemLucro = new System.Windows.Forms.TextBox();
            this.btVoltar = new System.Windows.Forms.Button();
            this.btSalvarProduto = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.lbNomeTela = new System.Windows.Forms.Label();
            this.cbxFornecedor = new System.Windows.Forms.ComboBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // label1_CodBarras
            // 
            this.label1_CodBarras.AutoSize = true;
            this.label1_CodBarras.Font = new System.Drawing.Font("Century Gothic", 10.2F);
            this.label1_CodBarras.Location = new System.Drawing.Point(12, 64);
            this.label1_CodBarras.Name = "label1_CodBarras";
            this.label1_CodBarras.Size = new System.Drawing.Size(84, 19);
            this.label1_CodBarras.TabIndex = 0;
            this.label1_CodBarras.Text = "Cód Barras";
            // 
            // label2_Idinterno
            // 
            this.label2_Idinterno.AutoSize = true;
            this.label2_Idinterno.Font = new System.Drawing.Font("Century Gothic", 10.2F);
            this.label2_Idinterno.Location = new System.Drawing.Point(12, 89);
            this.label2_Idinterno.Name = "label2_Idinterno";
            this.label2_Idinterno.Size = new System.Drawing.Size(74, 19);
            this.label2_Idinterno.TabIndex = 1;
            this.label2_Idinterno.Text = "ID Interno";
            // 
            // label3_nomeProduto
            // 
            this.label3_nomeProduto.AutoSize = true;
            this.label3_nomeProduto.Font = new System.Drawing.Font("Century Gothic", 10.2F);
            this.label3_nomeProduto.Location = new System.Drawing.Point(13, 115);
            this.label3_nomeProduto.Name = "label3_nomeProduto";
            this.label3_nomeProduto.Size = new System.Drawing.Size(50, 19);
            this.label3_nomeProduto.TabIndex = 2;
            this.label3_nomeProduto.Text = "Nome";
            // 
            // label4_qtde
            // 
            this.label4_qtde.AutoSize = true;
            this.label4_qtde.Font = new System.Drawing.Font("Century Gothic", 10.2F);
            this.label4_qtde.Location = new System.Drawing.Point(12, 139);
            this.label4_qtde.Name = "label4_qtde";
            this.label4_qtde.Size = new System.Drawing.Size(96, 19);
            this.label4_qtde.TabIndex = 3;
            this.label4_qtde.Text = "Quantidade";
            // 
            // label6_margemLucro
            // 
            this.label6_margemLucro.AutoSize = true;
            this.label6_margemLucro.Font = new System.Drawing.Font("Century Gothic", 10.2F);
            this.label6_margemLucro.Location = new System.Drawing.Point(12, 219);
            this.label6_margemLucro.Name = "label6_margemLucro";
            this.label6_margemLucro.Size = new System.Drawing.Size(108, 19);
            this.label6_margemLucro.TabIndex = 5;
            this.label6_margemLucro.Text = "Margem Lucro";
            // 
            // label10_precoVenda
            // 
            this.label10_precoVenda.AutoSize = true;
            this.label10_precoVenda.Font = new System.Drawing.Font("Century Gothic", 10.2F);
            this.label10_precoVenda.Location = new System.Drawing.Point(12, 193);
            this.label10_precoVenda.Name = "label10_precoVenda";
            this.label10_precoVenda.Size = new System.Drawing.Size(99, 19);
            this.label10_precoVenda.TabIndex = 9;
            this.label10_precoVenda.Text = "Preço Venda";
            // 
            // label11_precoCompra
            // 
            this.label11_precoCompra.AutoSize = true;
            this.label11_precoCompra.Font = new System.Drawing.Font("Century Gothic", 10.2F);
            this.label11_precoCompra.Location = new System.Drawing.Point(12, 165);
            this.label11_precoCompra.Name = "label11_precoCompra";
            this.label11_precoCompra.Size = new System.Drawing.Size(109, 19);
            this.label11_precoCompra.TabIndex = 10;
            this.label11_precoCompra.Text = "Preço Compra";
            // 
            // textcodbarras
            // 
            this.textcodbarras.Location = new System.Drawing.Point(122, 63);
            this.textcodbarras.Name = "textcodbarras";
            this.textcodbarras.Size = new System.Drawing.Size(369, 20);
            this.textcodbarras.TabIndex = 0;
            // 
            // textcodinterno
            // 
            this.textcodinterno.Location = new System.Drawing.Point(122, 88);
            this.textcodinterno.Name = "textcodinterno";
            this.textcodinterno.Size = new System.Drawing.Size(369, 20);
            this.textcodinterno.TabIndex = 1;
            // 
            // textnome
            // 
            this.textnome.Location = new System.Drawing.Point(122, 114);
            this.textnome.Name = "textnome";
            this.textnome.Size = new System.Drawing.Size(369, 20);
            this.textnome.TabIndex = 2;
            // 
            // textquantidade
            // 
            this.textquantidade.Location = new System.Drawing.Point(122, 140);
            this.textquantidade.Name = "textquantidade";
            this.textquantidade.Size = new System.Drawing.Size(369, 20);
            this.textquantidade.TabIndex = 3;
            this.textquantidade.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textquantidade_KeyPress);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 10.2F);
            this.label7.Location = new System.Drawing.Point(12, 245);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(85, 19);
            this.label7.TabIndex = 6;
            this.label7.Text = "Fabricante";
            // 
            // textprecocompra
            // 
            this.textprecocompra.Location = new System.Drawing.Point(122, 166);
            this.textprecocompra.Name = "textprecocompra";
            this.textprecocompra.Size = new System.Drawing.Size(369, 20);
            this.textprecocompra.TabIndex = 4;
            this.textprecocompra.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textprecocompra_KeyPress);
            // 
            // textprecovenda
            // 
            this.textprecovenda.Location = new System.Drawing.Point(121, 193);
            this.textprecovenda.Name = "textprecovenda";
            this.textprecovenda.Size = new System.Drawing.Size(369, 20);
            this.textprecovenda.TabIndex = 5;
            this.textprecovenda.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textprecovenda_KeyPress);
            // 
            // textmargemLucro
            // 
            this.textmargemLucro.Location = new System.Drawing.Point(121, 219);
            this.textmargemLucro.Name = "textmargemLucro";
            this.textmargemLucro.Size = new System.Drawing.Size(369, 20);
            this.textmargemLucro.TabIndex = 6;
            this.textmargemLucro.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textmargemLucro_KeyPress);
            // 
            // btVoltar
            // 
            this.btVoltar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(57)))), ((int)(((byte)(130)))));
            this.btVoltar.FlatAppearance.BorderSize = 0;
            this.btVoltar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Blue;
            this.btVoltar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.CornflowerBlue;
            this.btVoltar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btVoltar.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btVoltar.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btVoltar.Location = new System.Drawing.Point(5, 282);
            this.btVoltar.Name = "btVoltar";
            this.btVoltar.Size = new System.Drawing.Size(80, 35);
            this.btVoltar.TabIndex = 9;
            this.btVoltar.Text = "Voltar";
            this.btVoltar.UseVisualStyleBackColor = false;
            this.btVoltar.Click += new System.EventHandler(this.btVoltar_Click);
            // 
            // btSalvarProduto
            // 
            this.btSalvarProduto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(57)))), ((int)(((byte)(130)))));
            this.btSalvarProduto.FlatAppearance.BorderSize = 0;
            this.btSalvarProduto.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Blue;
            this.btSalvarProduto.FlatAppearance.MouseOverBackColor = System.Drawing.Color.CornflowerBlue;
            this.btSalvarProduto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btSalvarProduto.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btSalvarProduto.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btSalvarProduto.Location = new System.Drawing.Point(418, 282);
            this.btSalvarProduto.Name = "btSalvarProduto";
            this.btSalvarProduto.Size = new System.Drawing.Size(80, 35);
            this.btSalvarProduto.TabIndex = 8;
            this.btSalvarProduto.Text = "Salvar";
            this.btSalvarProduto.UseVisualStyleBackColor = false;
            this.btSalvarProduto.Click += new System.EventHandler(this.btSalvarProduto_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(57)))), ((int)(((byte)(130)))));
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.lbNomeTela);
            this.panel1.Location = new System.Drawing.Point(2, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(499, 34);
            this.panel1.TabIndex = 31;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::PDV_CLUSTERS.Properties.Resources.value;
            this.pictureBox2.Location = new System.Drawing.Point(345, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(66, 35);
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // lbNomeTela
            // 
            this.lbNomeTela.AutoSize = true;
            this.lbNomeTela.Font = new System.Drawing.Font("Century Gothic", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNomeTela.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lbNomeTela.Location = new System.Drawing.Point(3, -1);
            this.lbNomeTela.Name = "lbNomeTela";
            this.lbNomeTela.Size = new System.Drawing.Size(315, 36);
            this.lbNomeTela.TabIndex = 1;
            this.lbNomeTela.Text = "Cadastro de Produto";
            // 
            // cbxFornecedor
            // 
            this.cbxFornecedor.FormattingEnabled = true;
            this.cbxFornecedor.Location = new System.Drawing.Point(121, 245);
            this.cbxFornecedor.Name = "cbxFornecedor";
            this.cbxFornecedor.Size = new System.Drawing.Size(370, 21);
            this.cbxFornecedor.TabIndex = 7;
            // 
            // TelaManterCadastroProduto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(503, 325);
            this.Controls.Add(this.cbxFornecedor);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btSalvarProduto);
            this.Controls.Add(this.btVoltar);
            this.Controls.Add(this.textmargemLucro);
            this.Controls.Add(this.textprecovenda);
            this.Controls.Add(this.textprecocompra);
            this.Controls.Add(this.textquantidade);
            this.Controls.Add(this.textnome);
            this.Controls.Add(this.textcodinterno);
            this.Controls.Add(this.textcodbarras);
            this.Controls.Add(this.label11_precoCompra);
            this.Controls.Add(this.label10_precoVenda);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6_margemLucro);
            this.Controls.Add(this.label4_qtde);
            this.Controls.Add(this.label3_nomeProduto);
            this.Controls.Add(this.label2_Idinterno);
            this.Controls.Add(this.label1_CodBarras);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "TelaManterCadastroProduto";
            this.Text = "TelaManterCadastroProduto";
            this.Load += new System.EventHandler(this.TelaManterCadastro_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1_CodBarras;
        private System.Windows.Forms.Label label2_Idinterno;
        private System.Windows.Forms.Label label3_nomeProduto;
        private System.Windows.Forms.Label label4_qtde;
        private System.Windows.Forms.Label label6_margemLucro;
        private System.Windows.Forms.Label label10_precoVenda;
        private System.Windows.Forms.Label label11_precoCompra;
        private System.Windows.Forms.TextBox textcodbarras;
        private System.Windows.Forms.TextBox textcodinterno;
        private System.Windows.Forms.TextBox textnome;
        private System.Windows.Forms.TextBox textquantidade;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textprecocompra;
        private System.Windows.Forms.TextBox textprecovenda;
        private System.Windows.Forms.TextBox textmargemLucro;
        private System.Windows.Forms.Button btVoltar;
        private System.Windows.Forms.Button btSalvarProduto;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label lbNomeTela;
        private System.Windows.Forms.ComboBox cbxFornecedor;
    }
}