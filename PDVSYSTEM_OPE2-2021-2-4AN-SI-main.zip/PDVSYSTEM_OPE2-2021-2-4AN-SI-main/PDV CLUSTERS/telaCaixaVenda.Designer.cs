﻿
namespace PDV_CLUSTERS
{
    partial class telaCaixaVenda
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btVoltar = new System.Windows.Forms.Button();
            this.dgvListaItemVenda = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Excluir = new System.Windows.Forms.DataGridViewImageColumn();
            this.bindingSource5 = new System.Windows.Forms.BindingSource(this.components);
            this.pDVClusterDataSet1 = new PDV_CLUSTERS.PDVClusterDataSet1();
            this.bindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.pDVClusterDataSet = new PDV_CLUSTERS.PDVClusterDataSet();
            this.vWITEMPRODUTOBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtIdProduto = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.cbxCaixa = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.cbxFuncionario = new System.Windows.Forms.ComboBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lbNomeTela = new System.Windows.Forms.Label();
            this.txtIdVenda = new System.Windows.Forms.TextBox();
            this.lbIdVenda = new System.Windows.Forms.Label();
            this.txtCodProduto = new System.Windows.Forms.TextBox();
            this.txtQuantidade = new System.Windows.Forms.TextBox();
            this.txtPrecoUnit = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btPesquisarCaixa = new System.Windows.Forms.Button();
            this.txtSubTotal = new System.Windows.Forms.TextBox();
            this.txtDesconto = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cbxTipoPagamento = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtValorRecebido = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtTroco = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtTotal = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.btAdicionarCaixa = new System.Windows.Forms.Button();
            this.btFinalizarVenda = new System.Windows.Forms.Button();
            this.txtNomeProduto = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.bindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.bindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridViewImageColumn1 = new System.Windows.Forms.DataGridViewImageColumn();
            this.dataGridViewImageColumn2 = new System.Windows.Forms.DataGridViewImageColumn();
            this.tBCADASTROPRODUTOBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tBCADASTROFUNCIONARIOBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.txtCPF = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.tB_ITEM_VENDATableAdapter = new PDV_CLUSTERS.PDVClusterDataSet1TableAdapters.TB_ITEM_VENDATableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaItemVenda)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pDVClusterDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pDVClusterDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vWITEMPRODUTOBindingSource)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBCADASTROPRODUTOBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBCADASTROFUNCIONARIOBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // btVoltar
            // 
            this.btVoltar.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btVoltar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(57)))), ((int)(((byte)(130)))));
            this.btVoltar.FlatAppearance.BorderSize = 0;
            this.btVoltar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btVoltar.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.btVoltar.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btVoltar.Location = new System.Drawing.Point(24, 585);
            this.btVoltar.Name = "btVoltar";
            this.btVoltar.Size = new System.Drawing.Size(108, 54);
            this.btVoltar.TabIndex = 2;
            this.btVoltar.Text = "Voltar";
            this.btVoltar.UseVisualStyleBackColor = false;
            this.btVoltar.Click += new System.EventHandler(this.btVoltar_Click);
            // 
            // dgvListaItemVenda
            // 
            this.dgvListaItemVenda.AllowUserToAddRows = false;
            this.dgvListaItemVenda.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dgvListaItemVenda.AutoGenerateColumns = false;
            this.dgvListaItemVenda.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvListaItemVenda.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvListaItemVenda.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(66)))), ((int)(((byte)(91)))));
            this.dgvListaItemVenda.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvListaItemVenda.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(66)))), ((int)(((byte)(91)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Lavender;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvListaItemVenda.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvListaItemVenda.ColumnHeadersHeight = 30;
            this.dgvListaItemVenda.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvListaItemVenda.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.Excluir});
            this.dgvListaItemVenda.DataSource = this.bindingSource5;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.LightBlue;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.CornflowerBlue;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Lavender;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvListaItemVenda.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvListaItemVenda.EnableHeadersVisualStyles = false;
            this.dgvListaItemVenda.GridColor = System.Drawing.SystemColors.ActiveBorder;
            this.dgvListaItemVenda.Location = new System.Drawing.Point(24, 206);
            this.dgvListaItemVenda.Name = "dgvListaItemVenda";
            this.dgvListaItemVenda.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.CornflowerBlue;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Lavender;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvListaItemVenda.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvListaItemVenda.RowHeadersVisible = false;
            this.dgvListaItemVenda.RowHeadersWidth = 15;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.SteelBlue;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.CornflowerBlue;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.Lavender;
            this.dgvListaItemVenda.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvListaItemVenda.Size = new System.Drawing.Size(563, 373);
            this.dgvListaItemVenda.TabIndex = 13;
            this.dgvListaItemVenda.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gdListaItemVenda_CellContentClick);
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "ID";
            this.dataGridViewTextBoxColumn2.HeaderText = "ID";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Visible = false;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "ID_PRODUTO";
            this.dataGridViewTextBoxColumn3.HeaderText = "ID_PRODUTO";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Visible = false;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "NOME_PRODUTO";
            this.dataGridViewTextBoxColumn7.FillWeight = 118.6548F;
            this.dataGridViewTextBoxColumn7.HeaderText = "Nome";
            this.dataGridViewTextBoxColumn7.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "QTD";
            this.dataGridViewTextBoxColumn4.FillWeight = 118.6548F;
            this.dataGridViewTextBoxColumn4.HeaderText = "Quantidade";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "VALOR_UNITARIO";
            this.dataGridViewTextBoxColumn5.FillWeight = 118.6548F;
            this.dataGridViewTextBoxColumn5.HeaderText = "Valor";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "VALOR_SUBTOTAL";
            this.dataGridViewTextBoxColumn6.FillWeight = 118.6548F;
            this.dataGridViewTextBoxColumn6.HeaderText = "Subtotal";
            this.dataGridViewTextBoxColumn6.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            // 
            // Excluir
            // 
            this.Excluir.FillWeight = 25.38071F;
            this.Excluir.HeaderText = "";
            this.Excluir.Image = global::PDV_CLUSTERS.Properties.Resources.delete;
            this.Excluir.MinimumWidth = 6;
            this.Excluir.Name = "Excluir";
            this.Excluir.ReadOnly = true;
            // 
            // bindingSource5
            // 
            this.bindingSource5.DataMember = "TB_ITEM_VENDA";
            this.bindingSource5.DataSource = this.pDVClusterDataSet1;
            // 
            // pDVClusterDataSet1
            // 
            this.pDVClusterDataSet1.DataSetName = "PDVClusterDataSet1";
            this.pDVClusterDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // pDVClusterDataSet
            // 
            this.pDVClusterDataSet.DataSetName = "PDVClusterDataSet";
            this.pDVClusterDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // panel1
            // 
            this.panel1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(57)))), ((int)(((byte)(130)))));
            this.panel1.Controls.Add(this.txtIdProduto);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.cbxCaixa);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.cbxFuncionario);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.lbNomeTela);
            this.panel1.Controls.Add(this.txtIdVenda);
            this.panel1.Controls.Add(this.lbIdVenda);
            this.panel1.Location = new System.Drawing.Point(3, 1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(780, 46);
            this.panel1.TabIndex = 18;
            // 
            // txtIdProduto
            // 
            this.txtIdProduto.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtIdProduto.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtIdProduto.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtIdProduto.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIdProduto.HideSelection = false;
            this.txtIdProduto.Location = new System.Drawing.Point(4, 5);
            this.txtIdProduto.Name = "txtIdProduto";
            this.txtIdProduto.Size = new System.Drawing.Size(15, 37);
            this.txtIdProduto.TabIndex = 42;
            this.txtIdProduto.Visible = false;
            // 
            // label13
            // 
            this.label13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label13.Location = new System.Drawing.Point(451, 17);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(46, 17);
            this.label13.TabIndex = 26;
            this.label13.Text = "Caixa";
            // 
            // cbxCaixa
            // 
            this.cbxCaixa.FormattingEnabled = true;
            this.cbxCaixa.Location = new System.Drawing.Point(500, 16);
            this.cbxCaixa.Margin = new System.Windows.Forms.Padding(2);
            this.cbxCaixa.Name = "cbxCaixa";
            this.cbxCaixa.Size = new System.Drawing.Size(48, 21);
            this.cbxCaixa.TabIndex = 25;
            this.cbxCaixa.SelectionChangeCommitted += new System.EventHandler(this.cbxCaixa_SelectionChangeCommitted);
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label11.Location = new System.Drawing.Point(553, 17);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(83, 17);
            this.label11.TabIndex = 24;
            this.label11.Text = "Funcionário";
            // 
            // cbxFuncionario
            // 
            this.cbxFuncionario.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cbxFuncionario.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxFuncionario.FormattingEnabled = true;
            this.cbxFuncionario.Location = new System.Drawing.Point(637, 14);
            this.cbxFuncionario.Name = "cbxFuncionario";
            this.cbxFuncionario.Size = new System.Drawing.Size(127, 24);
            this.cbxFuncionario.TabIndex = 23;
            this.cbxFuncionario.SelectedValueChanged += new System.EventHandler(this.cbxFuncionario_SelectedValueChanged);
            this.cbxFuncionario.TextChanged += new System.EventHandler(this.cbxFuncionario_TextChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox1.Image = global::PDV_CLUSTERS.Properties.Resources.vetorCaixa;
            this.pictureBox1.Location = new System.Drawing.Point(149, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(74, 44);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // lbNomeTela
            // 
            this.lbNomeTela.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbNomeTela.AutoSize = true;
            this.lbNomeTela.Font = new System.Drawing.Font("Century Gothic", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNomeTela.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lbNomeTela.Location = new System.Drawing.Point(21, 6);
            this.lbNomeTela.Name = "lbNomeTela";
            this.lbNomeTela.Size = new System.Drawing.Size(100, 36);
            this.lbNomeTela.TabIndex = 0;
            this.lbNomeTela.Text = "Caixa";
            // 
            // txtIdVenda
            // 
            this.txtIdVenda.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtIdVenda.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtIdVenda.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtIdVenda.Enabled = false;
            this.txtIdVenda.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIdVenda.HideSelection = false;
            this.txtIdVenda.Location = new System.Drawing.Point(370, 15);
            this.txtIdVenda.Name = "txtIdVenda";
            this.txtIdVenda.Size = new System.Drawing.Size(76, 22);
            this.txtIdVenda.TabIndex = 19;
            // 
            // lbIdVenda
            // 
            this.lbIdVenda.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbIdVenda.AutoSize = true;
            this.lbIdVenda.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbIdVenda.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lbIdVenda.Location = new System.Drawing.Point(295, 17);
            this.lbIdVenda.Name = "lbIdVenda";
            this.lbIdVenda.Size = new System.Drawing.Size(70, 17);
            this.lbIdVenda.TabIndex = 22;
            this.lbIdVenda.Text = "Nº Venda";
            // 
            // txtCodProduto
            // 
            this.txtCodProduto.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtCodProduto.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtCodProduto.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtCodProduto.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCodProduto.HideSelection = false;
            this.txtCodProduto.Location = new System.Drawing.Point(21, 103);
            this.txtCodProduto.Name = "txtCodProduto";
            this.txtCodProduto.Size = new System.Drawing.Size(386, 37);
            this.txtCodProduto.TabIndex = 19;
            this.txtCodProduto.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCodProduto_KeyPress);
            // 
            // txtQuantidade
            // 
            this.txtQuantidade.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtQuantidade.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtQuantidade.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQuantidade.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQuantidade.HideSelection = false;
            this.txtQuantidade.Location = new System.Drawing.Point(416, 103);
            this.txtQuantidade.Name = "txtQuantidade";
            this.txtQuantidade.Size = new System.Drawing.Size(66, 37);
            this.txtQuantidade.TabIndex = 20;
            this.txtQuantidade.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQuantidade_KeyPress);
            // 
            // txtPrecoUnit
            // 
            this.txtPrecoUnit.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtPrecoUnit.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtPrecoUnit.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtPrecoUnit.Enabled = false;
            this.txtPrecoUnit.Font = new System.Drawing.Font("Century Gothic", 18F);
            this.txtPrecoUnit.HideSelection = false;
            this.txtPrecoUnit.Location = new System.Drawing.Point(487, 103);
            this.txtPrecoUnit.Name = "txtPrecoUnit";
            this.txtPrecoUnit.Size = new System.Drawing.Size(101, 37);
            this.txtPrecoUnit.TabIndex = 21;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(24, 83);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(136, 17);
            this.label1.TabIndex = 22;
            this.label1.Text = "Código do Produto";
            // 
            // btPesquisarCaixa
            // 
            this.btPesquisarCaixa.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btPesquisarCaixa.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(57)))), ((int)(((byte)(130)))));
            this.btPesquisarCaixa.FlatAppearance.BorderSize = 0;
            this.btPesquisarCaixa.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btPesquisarCaixa.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btPesquisarCaixa.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btPesquisarCaixa.Location = new System.Drawing.Point(600, 103);
            this.btPesquisarCaixa.Name = "btPesquisarCaixa";
            this.btPesquisarCaixa.Size = new System.Drawing.Size(175, 37);
            this.btPesquisarCaixa.TabIndex = 25;
            this.btPesquisarCaixa.Text = "Pesquisar";
            this.btPesquisarCaixa.UseVisualStyleBackColor = false;
            this.btPesquisarCaixa.Click += new System.EventHandler(this.btPesquisarCaixa_Click);
            // 
            // txtSubTotal
            // 
            this.txtSubTotal.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtSubTotal.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtSubTotal.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtSubTotal.Enabled = false;
            this.txtSubTotal.Font = new System.Drawing.Font("Century Gothic", 18F);
            this.txtSubTotal.HideSelection = false;
            this.txtSubTotal.Location = new System.Drawing.Point(601, 226);
            this.txtSubTotal.Name = "txtSubTotal";
            this.txtSubTotal.Size = new System.Drawing.Size(175, 37);
            this.txtSubTotal.TabIndex = 26;
            // 
            // txtDesconto
            // 
            this.txtDesconto.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtDesconto.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtDesconto.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtDesconto.Font = new System.Drawing.Font("Century Gothic", 18F);
            this.txtDesconto.HideSelection = false;
            this.txtDesconto.Location = new System.Drawing.Point(601, 286);
            this.txtDesconto.Name = "txtDesconto";
            this.txtDesconto.Size = new System.Drawing.Size(175, 37);
            this.txtDesconto.TabIndex = 27;
            this.txtDesconto.TextChanged += new System.EventHandler(this.txtDesconto_TextChanged);
            this.txtDesconto.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDesconto_KeyPress);
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(603, 206);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 17);
            this.label2.TabIndex = 28;
            this.label2.Text = "Subtotal";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(603, 326);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 17);
            this.label3.TabIndex = 29;
            this.label3.Text = "Total";
            // 
            // cbxTipoPagamento
            // 
            this.cbxTipoPagamento.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cbxTipoPagamento.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxTipoPagamento.FormattingEnabled = true;
            this.cbxTipoPagamento.Location = new System.Drawing.Point(601, 406);
            this.cbxTipoPagamento.Name = "cbxTipoPagamento";
            this.cbxTipoPagamento.Size = new System.Drawing.Size(175, 24);
            this.cbxTipoPagamento.TabIndex = 30;
            this.cbxTipoPagamento.SelectedIndexChanged += new System.EventHandler(this.cbxTipoPagamento_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(603, 386);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(137, 17);
            this.label4.TabIndex = 31;
            this.label4.Text = "Tipo de Pagamento";
            // 
            // txtValorRecebido
            // 
            this.txtValorRecebido.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtValorRecebido.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtValorRecebido.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtValorRecebido.Enabled = false;
            this.txtValorRecebido.Font = new System.Drawing.Font("Century Gothic", 18F);
            this.txtValorRecebido.HideSelection = false;
            this.txtValorRecebido.Location = new System.Drawing.Point(601, 461);
            this.txtValorRecebido.Name = "txtValorRecebido";
            this.txtValorRecebido.Size = new System.Drawing.Size(175, 37);
            this.txtValorRecebido.TabIndex = 32;
            this.txtValorRecebido.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtValorRecebido_KeyPress);
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(603, 441);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(108, 17);
            this.label5.TabIndex = 33;
            this.label5.Text = "Valor Recebido";
            // 
            // txtTroco
            // 
            this.txtTroco.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtTroco.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtTroco.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtTroco.Enabled = false;
            this.txtTroco.Font = new System.Drawing.Font("Century Gothic", 18F);
            this.txtTroco.HideSelection = false;
            this.txtTroco.Location = new System.Drawing.Point(601, 532);
            this.txtTroco.Name = "txtTroco";
            this.txtTroco.Size = new System.Drawing.Size(175, 37);
            this.txtTroco.TabIndex = 34;
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(603, 512);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(43, 17);
            this.label6.TabIndex = 35;
            this.label6.Text = "Troco";
            // 
            // txtTotal
            // 
            this.txtTotal.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtTotal.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtTotal.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtTotal.Enabled = false;
            this.txtTotal.Font = new System.Drawing.Font("Century Gothic", 18F);
            this.txtTotal.HideSelection = false;
            this.txtTotal.Location = new System.Drawing.Point(601, 346);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.Size = new System.Drawing.Size(175, 37);
            this.txtTotal.TabIndex = 36;
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(603, 266);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(93, 17);
            this.label7.TabIndex = 37;
            this.label7.Text = "Desconto (%)";
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(419, 83);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(33, 17);
            this.label8.TabIndex = 38;
            this.label8.Text = "Qtd";
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(489, 83);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(76, 17);
            this.label9.TabIndex = 39;
            this.label9.Text = "R$ Unitário";
            // 
            // btAdicionarCaixa
            // 
            this.btAdicionarCaixa.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btAdicionarCaixa.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(57)))), ((int)(((byte)(130)))));
            this.btAdicionarCaixa.FlatAppearance.BorderSize = 0;
            this.btAdicionarCaixa.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btAdicionarCaixa.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btAdicionarCaixa.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btAdicionarCaixa.Location = new System.Drawing.Point(601, 163);
            this.btAdicionarCaixa.Name = "btAdicionarCaixa";
            this.btAdicionarCaixa.Size = new System.Drawing.Size(174, 37);
            this.btAdicionarCaixa.TabIndex = 40;
            this.btAdicionarCaixa.Text = "Adicionar";
            this.btAdicionarCaixa.UseVisualStyleBackColor = false;
            this.btAdicionarCaixa.Click += new System.EventHandler(this.btAdicionarCaixa_Click);
            // 
            // btFinalizarVenda
            // 
            this.btFinalizarVenda.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btFinalizarVenda.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(57)))), ((int)(((byte)(130)))));
            this.btFinalizarVenda.FlatAppearance.BorderSize = 0;
            this.btFinalizarVenda.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btFinalizarVenda.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btFinalizarVenda.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btFinalizarVenda.Location = new System.Drawing.Point(434, 585);
            this.btFinalizarVenda.Name = "btFinalizarVenda";
            this.btFinalizarVenda.Size = new System.Drawing.Size(152, 56);
            this.btFinalizarVenda.TabIndex = 41;
            this.btFinalizarVenda.Text = "Finalizar venda";
            this.btFinalizarVenda.UseVisualStyleBackColor = false;
            this.btFinalizarVenda.Click += new System.EventHandler(this.btFinalizarVenda_Click);
            // 
            // txtNomeProduto
            // 
            this.txtNomeProduto.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtNomeProduto.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtNomeProduto.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtNomeProduto.Enabled = false;
            this.txtNomeProduto.Font = new System.Drawing.Font("Century Gothic", 18F);
            this.txtNomeProduto.HideSelection = false;
            this.txtNomeProduto.Location = new System.Drawing.Point(24, 163);
            this.txtNomeProduto.Name = "txtNomeProduto";
            this.txtNomeProduto.Size = new System.Drawing.Size(564, 37);
            this.txtNomeProduto.TabIndex = 19;
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(27, 143);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(126, 17);
            this.label10.TabIndex = 22;
            this.label10.Text = "Nome do Produto";
            // 
            // dataGridViewImageColumn1
            // 
            this.dataGridViewImageColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewImageColumn1.FillWeight = 106.599F;
            this.dataGridViewImageColumn1.HeaderText = "";
            this.dataGridViewImageColumn1.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Zoom;
            this.dataGridViewImageColumn1.MinimumWidth = 6;
            this.dataGridViewImageColumn1.Name = "dataGridViewImageColumn1";
            // 
            // dataGridViewImageColumn2
            // 
            this.dataGridViewImageColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewImageColumn2.FillWeight = 90.4138F;
            this.dataGridViewImageColumn2.HeaderText = "";
            this.dataGridViewImageColumn2.MinimumWidth = 6;
            this.dataGridViewImageColumn2.Name = "dataGridViewImageColumn2";
            // 
            // tBCADASTROFUNCIONARIOBindingSource
            // 
            this.tBCADASTROFUNCIONARIOBindingSource.DataMember = "TB_CADASTRO_FUNCIONARIO";
            // 
            // txtCPF
            // 
            this.txtCPF.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtCPF.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtCPF.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtCPF.Font = new System.Drawing.Font("Century Gothic", 18F);
            this.txtCPF.HideSelection = false;
            this.txtCPF.Location = new System.Drawing.Point(599, 602);
            this.txtCPF.Name = "txtCPF";
            this.txtCPF.Size = new System.Drawing.Size(177, 37);
            this.txtCPF.TabIndex = 34;
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(601, 582);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(33, 17);
            this.label12.TabIndex = 35;
            this.label12.Text = "CPF";
            // 
            // tB_ITEM_VENDATableAdapter
            // 
            this.tB_ITEM_VENDATableAdapter.ClearBeforeFill = true;
            // 
            // telaCaixaVenda
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(786, 714);
            this.Controls.Add(this.btFinalizarVenda);
            this.Controls.Add(this.btAdicionarCaixa);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtTotal);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtCPF);
            this.Controls.Add(this.txtTroco);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtValorRecebido);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cbxTipoPagamento);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtDesconto);
            this.Controls.Add(this.txtSubTotal);
            this.Controls.Add(this.btPesquisarCaixa);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtPrecoUnit);
            this.Controls.Add(this.txtQuantidade);
            this.Controls.Add(this.txtNomeProduto);
            this.Controls.Add(this.txtCodProduto);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.dgvListaItemVenda);
            this.Controls.Add(this.btVoltar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "telaCaixaVenda";
            this.Text = "telaCaixaVenda";
            this.Load += new System.EventHandler(this.telaCaixaVenda_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaItemVenda)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pDVClusterDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pDVClusterDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vWITEMPRODUTOBindingSource)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBCADASTROPRODUTOBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBCADASTROFUNCIONARIOBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion

        private System.Windows.Forms.Button btVoltar;
        private System.Windows.Forms.DataGridView dgvListaItemVenda;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lbNomeTela;
        private System.Windows.Forms.TextBox txtCodProduto;
        private System.Windows.Forms.TextBox txtQuantidade;
        private System.Windows.Forms.TextBox txtPrecoUnit;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btPesquisarCaixa;
        private System.Windows.Forms.TextBox txtSubTotal;
        private System.Windows.Forms.TextBox txtDesconto;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbxTipoPagamento;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtValorRecebido;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtTroco;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtTotal;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.BindingSource tBITEMVENDABindingSource;
        private System.Windows.Forms.Button btAdicionarCaixa;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDPRODUTODataGridViewTextBoxColumn;
        private System.Windows.Forms.Button btFinalizarVenda;
        private System.Windows.Forms.BindingSource tBITEMVENDABindingSource1;
        private System.Windows.Forms.BindingSource tBCADASTROPRODUTOBindingSource;
        private System.Windows.Forms.BindingSource tBCADASTROPRODUTOBindingSource1;
        private System.Windows.Forms.TextBox txtNomeProduto;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.BindingSource tBCADASTROFUNCIONARIOBindingSource;
        private System.Windows.Forms.TextBox txtIdVenda;
        private System.Windows.Forms.Label lbIdVenda;
        private System.Windows.Forms.ComboBox cbxFuncionario;
        private PDVClusterDataSet pDVClusterDataSet;
        private System.Windows.Forms.BindingSource bindingSource1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DataGridViewImageColumn dataGridViewImageColumn1;
        private System.Windows.Forms.DataGridViewImageColumn dataGridViewImageColumn2;
        private System.Windows.Forms.BindingSource vWITEMPRODUTOBindingSource;
        private System.Windows.Forms.BindingSource bindingSource2;
        private System.Windows.Forms.BindingSource bindingSource3;
        private System.Windows.Forms.BindingSource bindingSource4;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn nOMEPRODUTODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn qTDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn vALORUNITARIODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn vALORSUBTOTALDataGridViewTextBoxColumn;
        private System.Windows.Forms.TextBox txtCPF;
        private System.Windows.Forms.Label label12;
        private PDVClusterDataSet1 pDVClusterDataSet1;
        private System.Windows.Forms.BindingSource bindingSource5;
        private PDVClusterDataSet1TableAdapters.TB_ITEM_VENDATableAdapter tB_ITEM_VENDATableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewImageColumn Excluir;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox cbxCaixa;
        private System.Windows.Forms.TextBox txtIdProduto;
    }
}