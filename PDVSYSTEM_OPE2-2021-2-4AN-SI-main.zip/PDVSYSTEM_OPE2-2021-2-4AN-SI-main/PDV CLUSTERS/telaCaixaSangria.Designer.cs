﻿
namespace PDV_CLUSTERS
{
    partial class telaCaixaSangria
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btVoltar = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.lbNomeTela = new System.Windows.Forms.Label();
            this.txtDinheiro1 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtDebito1 = new System.Windows.Forms.TextBox();
            this.txtCredito1 = new System.Windows.Forms.TextBox();
            this.txtPix1 = new System.Windows.Forms.TextBox();
            this.txtQrcode1 = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtQrcode2 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtCredito2 = new System.Windows.Forms.TextBox();
            this.txtPix2 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtDinheiro2 = new System.Windows.Forms.TextBox();
            this.txtDebito2 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtQrcode3 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.txtCredito3 = new System.Windows.Forms.TextBox();
            this.txtPix3 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txtDinheiro3 = new System.Windows.Forms.TextBox();
            this.txtDebito3 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label19 = new System.Windows.Forms.Label();
            this.txtQrcode4 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.txtCredito4 = new System.Windows.Forms.TextBox();
            this.txtPix4 = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.txtDinheiro4 = new System.Windows.Forms.TextBox();
            this.txtDebito4 = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // btVoltar
            // 
            this.btVoltar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(57)))), ((int)(((byte)(130)))));
            this.btVoltar.FlatAppearance.BorderSize = 0;
            this.btVoltar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btVoltar.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btVoltar.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btVoltar.Location = new System.Drawing.Point(3, 672);
            this.btVoltar.Name = "btVoltar";
            this.btVoltar.Size = new System.Drawing.Size(80, 28);
            this.btVoltar.TabIndex = 25;
            this.btVoltar.Text = "Voltar";
            this.btVoltar.UseVisualStyleBackColor = false;
            this.btVoltar.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(57)))), ((int)(((byte)(130)))));
            this.panel3.Controls.Add(this.dateTimePicker1);
            this.panel3.Controls.Add(this.pictureBox2);
            this.panel3.Controls.Add(this.lbNomeTela);
            this.panel3.Location = new System.Drawing.Point(3, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(781, 42);
            this.panel3.TabIndex = 44;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Enabled = false;
            this.dateTimePicker1.Font = new System.Drawing.Font("Century Gothic", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Location = new System.Drawing.Point(263, 6);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(2);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(390, 30);
            this.dateTimePicker1.TabIndex = 34;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::PDV_CLUSTERS.Properties.Resources.vetorCaixa1;
            this.pictureBox2.Location = new System.Drawing.Point(134, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(56, 40);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // lbNomeTela
            // 
            this.lbNomeTela.AutoSize = true;
            this.lbNomeTela.Font = new System.Drawing.Font("Century Gothic", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNomeTela.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lbNomeTela.Location = new System.Drawing.Point(3, 2);
            this.lbNomeTela.Name = "lbNomeTela";
            this.lbNomeTela.Size = new System.Drawing.Size(123, 36);
            this.lbNomeTela.TabIndex = 0;
            this.lbNomeTela.Text = "Sangria";
            // 
            // txtDinheiro1
            // 
            this.txtDinheiro1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtDinheiro1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtDinheiro1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtDinheiro1.Enabled = false;
            this.txtDinheiro1.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDinheiro1.HideSelection = false;
            this.txtDinheiro1.Location = new System.Drawing.Point(145, 46);
            this.txtDinheiro1.Name = "txtDinheiro1";
            this.txtDinheiro1.Size = new System.Drawing.Size(199, 37);
            this.txtDinheiro1.TabIndex = 33;
            this.txtDinheiro1.Text = "0,00";
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(14, 46);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(131, 38);
            this.label7.TabIndex = 34;
            this.label7.Text = "Pagamento em\r\n Dinheiro";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(14, 102);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(131, 38);
            this.label2.TabIndex = 35;
            this.label2.Text = "Pagamento em\r\n Débito";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(14, 158);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(135, 38);
            this.label3.TabIndex = 36;
            this.label3.Text = "Pagamento em \r\nCrédito";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(14, 214);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(135, 38);
            this.label4.TabIndex = 37;
            this.label4.Text = "Pagamento em \r\nPIX";
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(14, 266);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(135, 38);
            this.label5.TabIndex = 38;
            this.label5.Text = "Pagamento em \r\nQRCode";
            // 
            // txtDebito1
            // 
            this.txtDebito1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtDebito1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtDebito1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtDebito1.Enabled = false;
            this.txtDebito1.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDebito1.HideSelection = false;
            this.txtDebito1.Location = new System.Drawing.Point(145, 102);
            this.txtDebito1.Name = "txtDebito1";
            this.txtDebito1.Size = new System.Drawing.Size(199, 37);
            this.txtDebito1.TabIndex = 39;
            this.txtDebito1.Text = "0,00";
            // 
            // txtCredito1
            // 
            this.txtCredito1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtCredito1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtCredito1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtCredito1.Enabled = false;
            this.txtCredito1.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCredito1.HideSelection = false;
            this.txtCredito1.Location = new System.Drawing.Point(145, 158);
            this.txtCredito1.Name = "txtCredito1";
            this.txtCredito1.Size = new System.Drawing.Size(199, 37);
            this.txtCredito1.TabIndex = 40;
            this.txtCredito1.Text = "0,00";
            // 
            // txtPix1
            // 
            this.txtPix1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtPix1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtPix1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtPix1.Enabled = false;
            this.txtPix1.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPix1.HideSelection = false;
            this.txtPix1.Location = new System.Drawing.Point(145, 214);
            this.txtPix1.Name = "txtPix1";
            this.txtPix1.Size = new System.Drawing.Size(199, 37);
            this.txtPix1.TabIndex = 41;
            this.txtPix1.Text = "0,00";
            // 
            // txtQrcode1
            // 
            this.txtQrcode1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtQrcode1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtQrcode1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQrcode1.Enabled = false;
            this.txtQrcode1.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQrcode1.HideSelection = false;
            this.txtQrcode1.Location = new System.Drawing.Point(145, 266);
            this.txtQrcode1.Name = "txtQrcode1";
            this.txtQrcode1.Size = new System.Drawing.Size(199, 37);
            this.txtQrcode1.TabIndex = 42;
            this.txtQrcode1.Text = "0,00";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtQrcode1);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtCredito1);
            this.groupBox1.Controls.Add(this.txtPix1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtDinheiro1);
            this.groupBox1.Controls.Add(this.txtDebito1);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(3, 50);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(367, 308);
            this.groupBox1.TabIndex = 45;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Caixa 01";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(182, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(134, 19);
            this.label1.TabIndex = 46;
            this.label1.Text = "Subtotal Período";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.txtQrcode2);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.txtCredito2);
            this.groupBox2.Controls.Add(this.txtPix2);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.txtDinheiro2);
            this.groupBox2.Controls.Add(this.txtDebito2);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(388, 50);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox2.Size = new System.Drawing.Size(367, 308);
            this.groupBox2.TabIndex = 47;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Caixa 02";
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(182, 13);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(134, 19);
            this.label6.TabIndex = 46;
            this.label6.Text = "Subtotal Período";
            // 
            // txtQrcode2
            // 
            this.txtQrcode2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtQrcode2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtQrcode2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQrcode2.Enabled = false;
            this.txtQrcode2.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQrcode2.HideSelection = false;
            this.txtQrcode2.Location = new System.Drawing.Point(145, 266);
            this.txtQrcode2.Name = "txtQrcode2";
            this.txtQrcode2.Size = new System.Drawing.Size(199, 37);
            this.txtQrcode2.TabIndex = 42;
            this.txtQrcode2.Text = "0,00";
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(14, 266);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(135, 38);
            this.label8.TabIndex = 38;
            this.label8.Text = "Pagamento em \r\nQRCode";
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(14, 46);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(131, 38);
            this.label9.TabIndex = 34;
            this.label9.Text = "Pagamento em\r\n Dinheiro";
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(14, 158);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(135, 38);
            this.label10.TabIndex = 36;
            this.label10.Text = "Pagamento em \r\nCrédito";
            // 
            // txtCredito2
            // 
            this.txtCredito2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtCredito2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtCredito2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtCredito2.Enabled = false;
            this.txtCredito2.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCredito2.HideSelection = false;
            this.txtCredito2.Location = new System.Drawing.Point(145, 158);
            this.txtCredito2.Name = "txtCredito2";
            this.txtCredito2.Size = new System.Drawing.Size(199, 37);
            this.txtCredito2.TabIndex = 40;
            this.txtCredito2.Text = "0,00";
            // 
            // txtPix2
            // 
            this.txtPix2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtPix2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtPix2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtPix2.Enabled = false;
            this.txtPix2.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPix2.HideSelection = false;
            this.txtPix2.Location = new System.Drawing.Point(145, 214);
            this.txtPix2.Name = "txtPix2";
            this.txtPix2.Size = new System.Drawing.Size(199, 37);
            this.txtPix2.TabIndex = 41;
            this.txtPix2.Text = "0,00";
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(14, 102);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(131, 38);
            this.label11.TabIndex = 35;
            this.label11.Text = "Pagamento em\r\n Débito";
            // 
            // txtDinheiro2
            // 
            this.txtDinheiro2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtDinheiro2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtDinheiro2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtDinheiro2.Enabled = false;
            this.txtDinheiro2.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDinheiro2.HideSelection = false;
            this.txtDinheiro2.Location = new System.Drawing.Point(145, 46);
            this.txtDinheiro2.Name = "txtDinheiro2";
            this.txtDinheiro2.Size = new System.Drawing.Size(199, 37);
            this.txtDinheiro2.TabIndex = 33;
            this.txtDinheiro2.Text = "0,00";
            // 
            // txtDebito2
            // 
            this.txtDebito2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtDebito2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtDebito2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtDebito2.Enabled = false;
            this.txtDebito2.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDebito2.HideSelection = false;
            this.txtDebito2.Location = new System.Drawing.Point(145, 102);
            this.txtDebito2.Name = "txtDebito2";
            this.txtDebito2.Size = new System.Drawing.Size(199, 37);
            this.txtDebito2.TabIndex = 39;
            this.txtDebito2.Text = "0,00";
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(14, 214);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(135, 38);
            this.label12.TabIndex = 37;
            this.label12.Text = "Pagamento em \r\nPIX";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.txtQrcode3);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.txtCredito3);
            this.groupBox3.Controls.Add(this.txtPix3);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Controls.Add(this.txtDinheiro3);
            this.groupBox3.Controls.Add(this.txtDebito3);
            this.groupBox3.Controls.Add(this.label18);
            this.groupBox3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(3, 360);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox3.Size = new System.Drawing.Size(367, 308);
            this.groupBox3.TabIndex = 48;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Caixa 03";
            // 
            // label13
            // 
            this.label13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(182, 13);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(134, 19);
            this.label13.TabIndex = 46;
            this.label13.Text = "Subtotal Período";
            // 
            // txtQrcode3
            // 
            this.txtQrcode3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtQrcode3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtQrcode3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQrcode3.Enabled = false;
            this.txtQrcode3.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQrcode3.HideSelection = false;
            this.txtQrcode3.Location = new System.Drawing.Point(145, 266);
            this.txtQrcode3.Name = "txtQrcode3";
            this.txtQrcode3.Size = new System.Drawing.Size(199, 37);
            this.txtQrcode3.TabIndex = 42;
            this.txtQrcode3.Text = "0,00";
            // 
            // label14
            // 
            this.label14.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(14, 266);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(135, 38);
            this.label14.TabIndex = 38;
            this.label14.Text = "Pagamento em \r\nQRCode";
            // 
            // label15
            // 
            this.label15.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(14, 46);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(131, 38);
            this.label15.TabIndex = 34;
            this.label15.Text = "Pagamento em\r\n Dinheiro";
            // 
            // label16
            // 
            this.label16.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(14, 158);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(135, 38);
            this.label16.TabIndex = 36;
            this.label16.Text = "Pagamento em \r\nCrédito";
            // 
            // txtCredito3
            // 
            this.txtCredito3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtCredito3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtCredito3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtCredito3.Enabled = false;
            this.txtCredito3.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCredito3.HideSelection = false;
            this.txtCredito3.Location = new System.Drawing.Point(145, 158);
            this.txtCredito3.Name = "txtCredito3";
            this.txtCredito3.Size = new System.Drawing.Size(199, 37);
            this.txtCredito3.TabIndex = 40;
            this.txtCredito3.Text = "0,00";
            // 
            // txtPix3
            // 
            this.txtPix3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtPix3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtPix3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtPix3.Enabled = false;
            this.txtPix3.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPix3.HideSelection = false;
            this.txtPix3.Location = new System.Drawing.Point(145, 214);
            this.txtPix3.Name = "txtPix3";
            this.txtPix3.Size = new System.Drawing.Size(199, 37);
            this.txtPix3.TabIndex = 41;
            this.txtPix3.Text = "0,00";
            // 
            // label17
            // 
            this.label17.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(14, 102);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(131, 38);
            this.label17.TabIndex = 35;
            this.label17.Text = "Pagamento em\r\n Débito";
            // 
            // txtDinheiro3
            // 
            this.txtDinheiro3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtDinheiro3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtDinheiro3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtDinheiro3.Enabled = false;
            this.txtDinheiro3.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDinheiro3.HideSelection = false;
            this.txtDinheiro3.Location = new System.Drawing.Point(145, 46);
            this.txtDinheiro3.Name = "txtDinheiro3";
            this.txtDinheiro3.Size = new System.Drawing.Size(199, 37);
            this.txtDinheiro3.TabIndex = 33;
            this.txtDinheiro3.Text = "0,00";
            // 
            // txtDebito3
            // 
            this.txtDebito3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtDebito3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtDebito3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtDebito3.Enabled = false;
            this.txtDebito3.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDebito3.HideSelection = false;
            this.txtDebito3.Location = new System.Drawing.Point(145, 102);
            this.txtDebito3.Name = "txtDebito3";
            this.txtDebito3.Size = new System.Drawing.Size(199, 37);
            this.txtDebito3.TabIndex = 39;
            this.txtDebito3.Text = "0,00";
            // 
            // label18
            // 
            this.label18.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(14, 214);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(135, 38);
            this.label18.TabIndex = 37;
            this.label18.Text = "Pagamento em \r\nPIX";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.txtQrcode4);
            this.groupBox4.Controls.Add(this.label20);
            this.groupBox4.Controls.Add(this.label21);
            this.groupBox4.Controls.Add(this.label22);
            this.groupBox4.Controls.Add(this.txtCredito4);
            this.groupBox4.Controls.Add(this.txtPix4);
            this.groupBox4.Controls.Add(this.label23);
            this.groupBox4.Controls.Add(this.txtDinheiro4);
            this.groupBox4.Controls.Add(this.txtDebito4);
            this.groupBox4.Controls.Add(this.label24);
            this.groupBox4.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(388, 360);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox4.Size = new System.Drawing.Size(367, 308);
            this.groupBox4.TabIndex = 48;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Caixa 04";
            // 
            // label19
            // 
            this.label19.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(182, 13);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(134, 19);
            this.label19.TabIndex = 46;
            this.label19.Text = "Subtotal Período";
            // 
            // txtQrcode4
            // 
            this.txtQrcode4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtQrcode4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtQrcode4.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtQrcode4.Enabled = false;
            this.txtQrcode4.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQrcode4.HideSelection = false;
            this.txtQrcode4.Location = new System.Drawing.Point(145, 266);
            this.txtQrcode4.Name = "txtQrcode4";
            this.txtQrcode4.Size = new System.Drawing.Size(199, 37);
            this.txtQrcode4.TabIndex = 42;
            this.txtQrcode4.Text = "0,00";
            // 
            // label20
            // 
            this.label20.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(14, 266);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(135, 38);
            this.label20.TabIndex = 38;
            this.label20.Text = "Pagamento em \r\nQRCode";
            // 
            // label21
            // 
            this.label21.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(14, 46);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(131, 38);
            this.label21.TabIndex = 34;
            this.label21.Text = "Pagamento em\r\n Dinheiro";
            // 
            // label22
            // 
            this.label22.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(14, 158);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(135, 38);
            this.label22.TabIndex = 36;
            this.label22.Text = "Pagamento em \r\nCrédito";
            // 
            // txtCredito4
            // 
            this.txtCredito4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtCredito4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtCredito4.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtCredito4.Enabled = false;
            this.txtCredito4.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCredito4.HideSelection = false;
            this.txtCredito4.Location = new System.Drawing.Point(145, 158);
            this.txtCredito4.Name = "txtCredito4";
            this.txtCredito4.Size = new System.Drawing.Size(199, 37);
            this.txtCredito4.TabIndex = 40;
            this.txtCredito4.Text = "0,00";
            // 
            // txtPix4
            // 
            this.txtPix4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtPix4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtPix4.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtPix4.Enabled = false;
            this.txtPix4.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPix4.HideSelection = false;
            this.txtPix4.Location = new System.Drawing.Point(145, 214);
            this.txtPix4.Name = "txtPix4";
            this.txtPix4.Size = new System.Drawing.Size(199, 37);
            this.txtPix4.TabIndex = 41;
            this.txtPix4.Text = "0,00";
            // 
            // label23
            // 
            this.label23.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(14, 102);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(131, 38);
            this.label23.TabIndex = 35;
            this.label23.Text = "Pagamento em\r\n Débito";
            // 
            // txtDinheiro4
            // 
            this.txtDinheiro4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtDinheiro4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtDinheiro4.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtDinheiro4.Enabled = false;
            this.txtDinheiro4.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDinheiro4.HideSelection = false;
            this.txtDinheiro4.Location = new System.Drawing.Point(145, 46);
            this.txtDinheiro4.Name = "txtDinheiro4";
            this.txtDinheiro4.Size = new System.Drawing.Size(199, 37);
            this.txtDinheiro4.TabIndex = 33;
            this.txtDinheiro4.Text = "0,00";
            // 
            // txtDebito4
            // 
            this.txtDebito4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtDebito4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtDebito4.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtDebito4.Enabled = false;
            this.txtDebito4.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDebito4.HideSelection = false;
            this.txtDebito4.Location = new System.Drawing.Point(145, 102);
            this.txtDebito4.Name = "txtDebito4";
            this.txtDebito4.Size = new System.Drawing.Size(199, 37);
            this.txtDebito4.TabIndex = 39;
            this.txtDebito4.Text = "0,00";
            // 
            // label24
            // 
            this.label24.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(14, 214);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(135, 38);
            this.label24.TabIndex = 37;
            this.label24.Text = "Pagamento em \r\nPIX";
            // 
            // telaCaixaSangria
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(786, 714);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.btVoltar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "telaCaixaSangria";
            this.Text = "telaCaixaSangria";
            this.Load += new System.EventHandler(this.telaCaixaSangria_Load);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btVoltar;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label lbNomeTela;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox txtDinheiro1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtDebito1;
        private System.Windows.Forms.TextBox txtCredito1;
        private System.Windows.Forms.TextBox txtPix1;
        private System.Windows.Forms.TextBox txtQrcode1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtQrcode2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtCredito2;
        private System.Windows.Forms.TextBox txtPix2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtDinheiro2;
        private System.Windows.Forms.TextBox txtDebito2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtQrcode3;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtCredito3;
        private System.Windows.Forms.TextBox txtPix3;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtDinheiro3;
        private System.Windows.Forms.TextBox txtDebito3;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtQrcode4;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtCredito4;
        private System.Windows.Forms.TextBox txtPix4;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txtDinheiro4;
        private System.Windows.Forms.TextBox txtDebito4;
        private System.Windows.Forms.Label label24;
    }
}